<?php
if (isset($_POST['login'])) { 
	$login = $_POST['login']; 
	if ($login == '') {
 		unset($login);
 	} 
}

if (isset($_POST['password'])) { 
	$password=$_POST['password']; 
	if ($password =='') { 
		unset($password);
	}
}
if (empty($login) or empty($password)){
exit ("You didn't  enter a all information, go back and fill in all fields!");
}
$login = stripslashes($login);
$login = htmlspecialchars($login);

$password = stripslashes($password);
$password = htmlspecialchars($password);

$login = trim($login);
$password = trim($password);


if (strlen($login) < 3 or strlen($login) > 15) {
exit ("3<=login<=15");
}
if (strlen($password) < 3 or strlen($password) > 15) {
exit ("3<password<15");
}


if (!empty($_POST['fupload'])) 
{
$fupload=$_POST['fupload']; $fupload = trim($fupload); 
  if ($fupload =='' or empty($fupload)) {
        unset($fupload);
	}
}

if (!isset($fupload) or empty($fupload) or $fupload =='')
{
$avatar = "avatars/net-avatara.jpg"; 
}

else{
$path_to_90_directory = 'avatars/';

if(preg_match('/[.](JPG)|(jpg)|(gif)|(GIF)|(png)|(PNG)$/',$_FILES['fupload']['name'])){	
	$filename = $_FILES['fupload']['name'];
	$source = $_FILES['fupload']['tmp_name'];	
	$target = $path_to_90_directory . $filename;
	move_uploaded_file($source, $target);

	if(preg_match('/[.](GIF)|(gif)$/', $filename)) {
		$im = imagecreatefromgif($path_to_90_directory.$filename) ; 
	}
	if(preg_match('/[.](PNG)|(png)$/', $filename)) {
		$im = imagecreatefrompng($path_to_90_directory.$filename) ;
	}	
	if(preg_match('/[.](JPG)|(jpg)|(jpeg)|(JPEG)$/', $filename)) {
		$im = imagecreatefromjpeg($path_to_90_directory.$filename); 
	}

	$width = 90; 
	$w_src = imagesx($im);
	$h_src = imagesy($im);
	$dest = imagecreatetruecolor($width,$width); 
	if ($w_src>$h_src){
         imagecopyresampled($dest, $im, 0, 0,
         	round((max($w_src,$h_src)-min($w_src,$h_src))/2),
         	0, $width, $width, min($w_src,$h_src), min($w_src,$h_src)); 
     }
    if ($w_src<$h_src) {
         imagecopyresampled($dest, $im, 0, 0, 0, 0, $width, $width,
                          min($w_src,$h_src), min($w_src,$h_src)); 
      }   
    if ($w_src==$h_src){
         imagecopyresampled($dest, $im, 0, 0, 0, 0, $width, $width, $w_src, $w_src); 
		$date=time(); 
		imagejpeg($dest, $path_to_90_directory.$date.".jpg");

	$avatar = $path_to_90_directory.$date.".jpg";
	$delfull = $path_to_90_directory.$filename; 
	unlink ($delfull);
}
}
else{ 
    exit ("Picture must be in the format <strong> JPG, GIF or PNG </ strong>");
	}
}
include ("datab.php");

// $query="SELECT id FROM users WHERE login='$login'";

// echo "$query";
// $result = mysql_query($query);

// while ($myrow = mysql_fetch_array($result)) {
// 	if (!empty($myrow['id'])) {
// 		exit ("Sorry, you entered login is already registered.");
// 	}
// }

$q = "INSERT INTO users VALUES(null,'$login','$password','$avatar')";
$result2 = mysql_query ($q);

if ($result2=='TRUE')
{
   header ('Location: index.php');  
   exit();    
}

// else {
// echo "Error";
// }
 
?>