<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="soup.css">
</head>
<body>
	<div class ="logo">CafECo</div>
<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<p class="name">The Drinks</p>
	<table class="s">
	<tr>
	<td>   		
   	<div class="soup">
   		<a href="coffee.php"><img src="coffee.jpg" width="250px";height="140px"></a>
  		<a href="coffee.php" class="kind">Coffee</a>
   	</div>
   	</td>
   	<td>
   	<div class="soup">
   		<a href="juice.php"><img src="juice.jpg" width="250px";height="140px"></a>
  		<a href="juice.php" class="kind">Juice</a>
   	</div>
   	</td>
    <td>
    <div class="soup">
      <a href="fizzydrinks.php"><img src="fizzydrinks.jpg" width="250px";height="140px"></a>
      <a href="fizzydrinks.php" class="kind">Fizzy drinks</a>
    </div>
    </td>
   	</tr>
   	</table>
   	<div class="back">
      <a class="knopo4ka" href="menu.php">back to menu</a>
    </div>
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
</body>
</html>