<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="soup.css">
</head>
<body>
	<div class ="logo">CafECo</div>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<p class="name">The juice</p>
	<table class="s">
	<tr>
	<td><div class="soup">
   		<img src="juice1.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Pomegranate<br>2700T
    	</a>
   	</div>
   	</td>
	<td>   		
   	<div class="soup">
   		<img src="juice2.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Orange<br>1000T/1L
    	</a>
   	</div>
   	</td>
   	<td>
   	<div class="soup">
   		<img src="juice3.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Carrot<br>900T/1L
    	</a>
   	</div>
   	</td>
   	</tr>
	<tr> 
	<td>  
   	<div class="soup">
   		<img src="juice4.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Cherry<br>990T/1L
    	</a>
   	</div>
   	</td>
   	<td>
   		<div class="soup">
   		<img src="juice5.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Grapefruit<br>1200T/1L
    	</a>
   		</div>
   	</td>
   	<td>
   		<div class="soup">
   		<img src="juice6.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Tomate<br>1000T/1L
    	</a>
   		</div>
   	</td>
   	</tr>
   	</table>
    <div class="back">
      <a class="knopo4ka" href="drinks.php">back to drinks</a>
    </div>
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
</body>
</html>