<html>
<head>
    <link rel="stylesheet" href="web3.css">
    
</head>

<body>
<?php
    session_start();
if (isset($_POST['login'])) { 
	$login = $_POST['login']; 
	
	if (empty($login) or empty($password)){
    	exit ("You haven't entered all of the information, go back and fill in all fields!");
    }
  
    include ("datab.php"); 
    
    $result = mysql_query("SELECT * FROM users WHERE login='$login'"); 
    $row = mysql_fetch_array($result);
    if (empty($row['password'] || empty($row['login']))){
    	exit ("Login or password is empty");
    }
    else{
    	if ($row['password']==$password) {
    	$_SESSION['login']=$row['login']; 
	    $_SESSION['id']=$row['id'];
        ?>
       
        <?php
	    header ('Location:menu.php');  
	   	 
    }else{
        exit ("Login or password is incorrect");
    }
}
    ?>
    </body>
    </html>