<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="menu.css">
</head>
<body>
<div class="logo">CafEco</div>
</div>
<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
 <div id="parent_popup">
        <div id="window">
        <h2 id ="x" style="cursor: pointer;" onclick="document.getElementById('parent_popup').style.display='none';">   X</h2>
        <h1>You log in</h1>
        </div>
  </div>
<div class="menu"><b>The Menu</div>
  <table class="bla">
      <tr>
        <td>
        <div class="cart">
          <a href="soup.php"><img src="soup.jpg" width="300px"; height="200px"></a>
          <a href="soup.php" class="kind">Starter&side </a>
        </div>
        </td>
        <td>
        <div class="cart">
          <a href="maindishes.php"><img src="maindishes.jpg" width="300px";height="190px"></a>
          <a href="maindishes.php" class="kind">Main dishes</a>
        </div>
        </td>
      </tr>
      <tr> 
      <td> 
        <div class="cart">
          <a href="deserts.php"><img src="deserts.jpg" width="300px";height="200px"></a>
          <a href="deserts.php" class="kind">Deserts</a>
        </div>
      </td>
      <td>
      <div class="cart">
      <a href="Drinks.php"><img src="drinks.jpg" width="300px";height="200px"></a>
      <a href="Drinks.php" class="kind"> Drinks</a>
      </div> 
      </td>
      </tr> 
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

</body>
</html>