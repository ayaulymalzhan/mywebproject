<html>
<head>
<link rel="stylesheet" href="reservation.css">
</head>
<body>
<div class ="logo">CafECo</div>
<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>

<div>
    <p class="takyryp">Registration</p>
</div>
  <div class="reserve">
  <form action="save_user.php" method="post" enctype="multipart/form-data">
  <p>
  login*:
    <input name="login" type="text" placeholder = "login" size="15" maxlength="15"><br>
    </p>
  <p>
  password *:
    <input name="password" type="password" placeholder = "password" size="15" maxlength="15"><br>
  </p>
  <p>
  Choose an avatar:<br>
    <input type="FILE" name="fupload" value="select a file"><br>
  </p>
  <input type="submit" name="submit" value="submit">
 
</form>
</div>
</body>
</html>
