<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="fizzydrinks.css">
</head>
<body>
	<div class ="logo">CafECo</div>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<p class="name">The Main Dishes</p>
	<table class="s">
	<tr>
	<td><div class="soup">
   		<img src="wawlyk.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Lazy<br>2700T
    	</a>
   	</div>
   	</td>
	<td>   		
   	<div class="soup">
   		<img src="beefsteak.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Beef Steak<br>2000T
    	</a>
   	</div>
   	</td>
   	<td>
   	<div class="soup">
   		<img src="dishes3.jpg" width="250px";height="140px">
  		<a href="#" class="kind">Mexican rolls<br>2500T</a>
   	</div>
   	</td>
   	</tr>
	<tr> 
	<td>  
   	<div class="soup">
   		<img src="dishes4.jpg" width="250px";height="140px">
  		<a href="#" class="kind">Chinese chicken<br>1000T</a>
   	</div>
   	</td>
   	<td>
   		<div class="soup">
   		<img src="dishes5.jpg" width="250px";height="140px">
  		<a href="#" class="kind">Canadian Cheddar<br>1200T</a>
   		</div>
   	</td>
   	<td>
   		<div class="soup">
   		<img src="dishes6.jpg" width="250px";height="140px">
  		<a href="#" class="kind">Stuffed Peppers<br>3000T
    	</a>
   		</div>
   	</td>
   	</tr>
   	</table>
   	<div class="back">
      <a class="knopo4ka" href="menu.php">back to menu</a>
    </div>
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
</body>
</html>