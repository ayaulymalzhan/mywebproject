<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="soup.css">
</head>
<body>

	<div class ="logo">CafECo</div>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<p class="name">The starter</p>
	<table class="s">
	<tr>
	<td><div class="soup">
   		<img src="soup1.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Coconut Soup<br>850T
    	</a>
   	</div>
   	</td>
	<td>   		
   	<div class="soup">
   		<img src="soup2.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Green Godness<br>750T
    	</a>
   	</div>
   	</td>
   	<td>
   	<div class="soup">
   		<img src="soup3.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Bayou Shrimp<br>1000T
    	</a>
   	</div>
   	</td>
   	</tr>
	<tr> 
	<td>  
   	<div class="soup">
   		<img src="soup4.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Wonton soup<br>1000T
    	</a>
   	</div>
   	</td>
   	<td>
   		<div class="soup">
   		<img src="soup5.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Canadian Cheddar<br>1200T
    	</a>
   		</div>
   	</td>
   	<td>
   		<div class="soup">
   		<img src="soup6.jpg" width="250px";height="140px">
  		<a href="#" class="kind">
    	Minestrone<br>1200T
    	</a>
   		</div>
   	</td>
   	</tr>
   	</table>
   	<div class="back">
   		<a class="knopo4ka" href="menu.html">back to menu</a>
   	</div>
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>  	
</body>
</html>