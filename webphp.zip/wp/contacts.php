<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="contacts.css">
</head>
<body>
	<div class ="logo">CafECo</div>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<div>
		<table>
  		<tr>
  			<td class="address">
          <div id="googleMap" style="width:300px;height:300px;"></div>
          <script src="http://maps.googleapis.com/maps/api/js"></script>
          <script>
          var myCenter = new google.maps.LatLng(45.878114, -87.629798);

          function initialize() {
          var mapProp = {
            center:myCenter,
            zoom:6,
            scrollwheel:true,
            draggable:false,
            mapTypeId:google.maps.MapTypeId.ROADMAP
            };

          var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

          var marker = new google.maps.Marker({
            position:myCenter,
          });

          marker.setMap(map);
          }

          google.maps.event.addDomListener(window, 'load', initialize);
          </script>   
        </td>
    		<td class="c">Address:<br><br>Oak Kreek 5 Avenue</td>
    		<td class="c"><form>Phone number:<br><br>333-444-7</td>
    		<td class="c">Mail:<br><br><a href="#">CafEcores@gmail.com</a></td>
    		
        </tr>
  		
 	</table>
	</div>

<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

</body>
</html>