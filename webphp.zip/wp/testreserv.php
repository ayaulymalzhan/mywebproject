 <html>
 <body>
 <?php 
 session_start();
 include ("datab.php"); 
    $res=$_POST['res'];

    
    $result = mysql_query("INSERT INTO userr WHERE name='$name'"); 
    $row = mysql_fetch_array($result);
    if (empty($row['name'] || empty($row['phone'] ))){
    	exit ("empty");
    }
    else{
    	if ($row['name']=='res') {
    	$_SESSION['phone']=$row['phone']; 
	    $_SESSION['date']=$row['date'];
        $_SESSION['time']=$row['time'];
        $_SESSION['person']=$row['person'];
        ?>
       
        <?php
	    header ('Location: index.php');  
	   	exit();  
    }else{
        exit ("Login or password is incorrect");
    }
}
    ?>
    </body>
    </html>