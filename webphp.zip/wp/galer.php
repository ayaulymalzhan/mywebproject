<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<style type="text/css">
 .slider {
 z-index: 9;
 width: 700px;
 height: 290px;
 overflow: hidden;
 margin: 0 0 7px;
 position: relative;
 }
 .slider ul,
 .slider li {
 padding: 0;
 margin: 0;
 list-style-type: none;
 }
 .slider ul {
 width: 9999px; 
 }
 .slider ul li {
 list-style-type: none;
 float: left;
 width: 700px;
 height: 290px;
 }
 .slider .nav {
 position: absolute;
 left: 15px;
 bottom: 12px; 
 }
 .slider .nav span {
 opacity: 0.9;
 background: #fff;
 margin: 0 8px 0 0;
 width: 16px;
 height: 16px;
 border-radius: 8px;
 cursor: pointer;
 overflow: hidden;
 display: block;
 float: left;
 box-shadow: 0 1px 2px #000;
 }
 .slider .nav span.on {
 background: #2e9419;
 }
 #carousel_inner {
float:left;
width:700px; 
overflow: hidden;
background: #F0F0F0;
}

#carousel_ul {
position:relative;
left:-210px; 
list-style-type: none; 
margin: 0px;
padding: 0px;
width:9999px; 

padding-bottom:10px;
}

#carousel_ul li{
float: left;                         
width:200px;  
padding:0px;
height:110px;
background: #000000;
margin-top:10px;
margin-bottom:10px; 
margin-left:5px; 
margin-right:5px; 
}

#carousel_ul li img {
.margin-bottom:-4px;
cursor:pointer;
cursor: hand; 
border:0px; 
}
#left_scroll, #right_scroll{
float:left; 
height:140px; 
width:15px; 
background: #C0C0C0; 
}
#left_scroll img, #right_scroll img{
/*styling*/
cursor: pointer;
cursor: hand;
}
#carousel_container{
  margin: auto;
}
</style>
<link rel="stylesheet" href="galer.css">
</head>
<body>
	<div class ="logo">CafECo</div>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
        $('#carousel_ul li:first').before($('#carousel_ul li:last')); 
              
        $('#right_scroll img').click(function(){
            var item_width = $('#carousel_ul li').outerWidth() + 10;
       
            var left_indent = parseInt($('#carousel_ul').css('left')) - item_width;

            $('#carousel_ul:not(:animated)').animate({'left' : left_indent},500,function(){    
             
                $('#carousel_ul li:last').after($('#carousel_ul li:first')); 
                
 
                $('#carousel_ul').css({'left' : '-210px'});
            }); 
        });
      
        $('#left_scroll img').click(function(){
            
            var item_width = $('#carousel_ul li').outerWidth() + 10;
            
            var left_indent = parseInt($('#carousel_ul').css('left')) + item_width;
            
            $('#carousel_ul:not(:animated)').animate({'left' : left_indent},500,function(){           
            $('#carousel_ul li:first').before($('#carousel_ul li:last')); 
            
          
            $('#carousel_ul').css({'left' : '-210px'});
            });
            
            
        });
  });
</script>
</head>
<body>
<h1 style='color:black'>Gallery</h1>
  <div id='carousel_container'>
  <div id='left_scroll'><img src='left.png' /></div>
    <div id='carousel_inner'>
        <ul id='carousel_ul'>
            <li><img src='g1.jpg' /></li>
            <li><img src='g1.jpg' /></li>
            <li><img src='g1.jpg' /></li>
            <li><img src='g1.jpg' /></li>
        </ul>
    </div>
  <div id='right_scroll'><img src='right.png' /></div>
  </div>
</body>
</html>
        
</body>
</html>