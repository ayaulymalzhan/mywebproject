<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="mainpage.css">
</head>
<body>
	<div class ="logo">CafECo</div>
  <form action="testreg.php" method="post" class="log">
  <p>login:<br><input name="login" type="text" placeholder = "login" size="15" maxlength="15"><br> </p>
  <p>password:<br><input name="password" type="password" placeholder = "password" size="15" maxlength="15"><br></p>
  Remember me<input name="save" type="checkbox" value='1'><br>
  <input type="submit" name="submit" value="Log in">
  <a href="reg.php">Sign up</a>

</form>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<div class="menu">
		<p class = "m">
			ENJOY A WONDERFUL<br>DINING EXPERIENCE
		</p>
		<p class="simple">Simple but delicious food</p>
		<a class="sylka" href="menu.php">get to menu</a>
		
	
	</div>
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>	



</body>
</html>