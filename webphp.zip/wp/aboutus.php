<!DOCTYPE html>
<html>
<head>
<title>CafEco</title>
<link rel="stylesheet" href="aboutus1.css">
</head>
<body>
<div class ="logo">CafECo</div>
	<ul>
    <li><a class="knopka" href="contacts.php"><b>Contacts</b></a></li>
    <li><a class="knopka" href="aboutus.php"><b>About us</b></a></li>
    <li><a class="knopka" href="reservation.php"><b>Reservation</b></a></li>
    <li class="dropdown">
      <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()"><b>The menu</b></a>
      <div class="dropdown-content" id="myDropdown">
        <a href="soup.php">Starter&side</a>
        <a href="maindishes.php">Main dishes</a>
        <a href="deserts.php">Deserts</a>
        <a href="drinks.php">Drinks</a>
      </div>
    </li>
    <li><a class="knopka" href="galer.php"><b>Gallery</b></a></li>
    <li><a class="knopka" href="index.php"><b>Home</b></a></li>
  </ul>
	<h1 class="a">About us</h1>
	<p class="bla">CafEco - family-style restaurant. European - cuisine direction. The menu has a lot of author cuisine of our chef Uncle Gene, who have already become hits.</p>
	<p class="ourteam"><b>Our team</b></p>
	<div class="team">
		<div class="cart">
   			<img src="chef.jpg" width="150px"; height="140px">
  				<a href="#" class="price">
    				Chief-cooker
    			</a>
   		</div>
	
		<div class="cart">
   			<img src="konditer.jpg" width="150px"; height="140px">
  				<a href="#" class="price">
    				Confectioner
    			</a>
   		</div>
		
		<div class="cart">
   			<img src="director.jpg" width="150px"; height="140px">
  				<a href="#" class="price">
    				Director
    			</a>
   		</div>
	</div>
	
<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

</script>
</body>
</html>